fx_version 'cerulean'
game 'gta5'

name 'Vehicle Weapon Storage'
author 'Toasted Development'
version '1.0.0'
description 'Store weapons in emergency service vehicles'

client_scripts {
    '@menuv/menuv.lua',
    'stream/*.ytd',
    'toast_loadout-menu.lua'
}
